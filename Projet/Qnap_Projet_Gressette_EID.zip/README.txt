Le projet était très difficile et nous avons rencontré de nombreux obstacles tout au long de son déroulement. Nous avons réalisé que nous manquions de précieuses heures de TP, environ 6-8 heures, qui auraient pu nous aider à réussir plus rapidement et efficacement. Cependant, malgré ces difficultés, nous avons apprécié ce module de cours sur l'ingénierie de trafic. C'est un pan intéressant de notre métier qui nous a permis de découvrir de nouvelles compétences et de les appliquer à des situations réelles.

Dans ce directory, vous trouverez : 
-Les fichiers Qnap dans un .zip
-le compte rendu .pdf
-ce fichier